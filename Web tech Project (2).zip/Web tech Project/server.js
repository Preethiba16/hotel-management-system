const express = require('express');
const path = require('path');
const { MongoClient } = require('mongodb');
const session = require('express-session');
const cors = require('cors');
const bcrypt = require('bcrypt'); // For hashing passwords

const app = express();

// MongoDB setup
const uri = 'mongodb://localhost:27017/';
const dbName = 'Hotel';

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static('public'));

// Session configuration
app.use(session({
    secret: 'your_secret_key', // Replace with a strong secret
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, sameSite: 'strict' } // Set secure to true in production
}));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Sign up route
app.post('/sign_up', async (req, res) => {
    const { Name, password } = req.body;

    try {
        const client = new MongoClient(uri);
        await client.connect();
        console.log('Connected to MongoDB');

        const db = client.db(dbName);
        const collection = db.collection('signups');

        // Hash the password before storing it
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert user data
        await collection.insertOne({ Name, password: hashedPassword });
        console.log('User Registered:', Name);

        res.sendFile(path.join(__dirname, 'public', 'sucess.html'));
    } catch (error) {
        console.error('Error during signup:', error);
        res.status(500).send('Error saving data.');
    }
});

// Login route
app.post('/login', async (req, res) => {
    const { Name, password } = req.body;

    const client = new MongoClient(uri);

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('signups');

        const user = await collection.findOne({ Name });
        if (user && await bcrypt.compare(password, user.password)) {
            req.session.Name = Name;
            res.send(`<script>alert('Logged In Successfully!'); window.location.href = "/Rooms.html";</script>`);
        } else {
            res.send(`<script>alert('Invalid credentials!'); window.location.href = "/login.html";</script>`);
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).send('Login error.');
    } finally {
        await client.close();
    }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
