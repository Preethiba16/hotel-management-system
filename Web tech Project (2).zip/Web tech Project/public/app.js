var app = angular.module('countryClubApp', []);

app.controller('RoomController', function($scope, $location) {
  $scope.rooms = [
    {
      name: 'Deluxe Room',
      price: 7500,
      rating: 4,
      image: 'https://www.homestratosphere.com/wp-content/uploads/2014/06/shutterstock_46024522.jpg'
    },
    {
      name: 'Luxury Room',
      price: 7000,
      rating: 4,
      image: 'https://wallpapercave.com/wp/wp2406803.jpg'
    },
    {
      name: 'Guest House',
      price: 3400,
      rating: 3,
      image: 'https://wallpapercave.com/wp/wp7113919.jpg'
    },
    {
      name: 'Single Room',
      price: 1400,
      rating: 2,
      image: 'https://www.wallpaperflare.com/static/261/473/239/bedroom-pillow-design-modern-wallpaper.jpg'
    },
    {
      name: 'Premium Suite',
      price: 8500,
      rating: 5,
      image: 'https://i.pinimg.com/originals/2e/b8/c1/2eb8c1931b139d6052f6c3262bcd8d80.jpg'
    },
    {
      name: 'Economy Room',
      price: 3000,
      rating: 3,
      image: 'https://wallpapercave.com/wp/wp6957327.jpg'
    },
    {
      name: 'Double Deluxe',
      price: 6200,
      rating: 4,
      image: 'https://images8.alphacoders.com/109/thumb-1920-1099107.jpg'
    },
    {
      name: 'Junior Suite',
      price: 5000,
      rating: 4,
      image: 'https://i.pinimg.com/originals/54/47/c7/5447c76323d6f6f93c24eba837587b97.jpg'
    }
  ];

  // Function to book a room
  $scope.bookRoom = function(room) {
    // Redirect to booking-status.html with the room name and price as query parameters
    var url = 'booking-status.html?roomName=' + encodeURIComponent(room.name) + '&price=' + room.price;
    window.location.href = url;  // Redirect with room details
  };
});
