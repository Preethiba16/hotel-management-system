let slideIndex = 0;
let slideInterval;

function redirectToSignUp() {
    window.location.href = '/signup.html';
}

function redirectToLogin() {
    window.location.href = '/login.html';
}
$routeProvider
    .when("/", {
      templateUrl: "Home.html"
    })
$routeProvider
    .when("/rooms", {
      templateUrl: "Rooms.html",
      controller: "RoomController"
    });

// Function to show the slides
function showSlides() {
    const slides = document.getElementsByClassName("slide");

    // Loop through all slides and hide them
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }

    // Increment slide index and reset if necessary
    slideIndex++;
    if (slideIndex >= slides.length) { 
        slideIndex = 0; 
    }

    // Display the current slide
    slides[slideIndex].style.display = "block";  
    slides[slideIndex].classList.add('fade'); // Add fade class

    // Clear the previous interval and set a new one
    clearInterval(slideInterval);
    slideInterval = setInterval(showSlides, 5000); 
}

// Function to change to the next slide
function nextSlide() {
    const slides = document.getElementsByClassName("slide");
    slides[slideIndex].style.display = "none"; // Hide current slide
    slideIndex = (slideIndex + 1) % slides.length; // Update index
    slides[slideIndex].style.display = "block"; // Show next slide
    slides[slideIndex].classList.add('fade'); // Add fade class
}

// Function to change to the previous slide
function prevSlide() {
    const slides = document.getElementsByClassName("slide");
    slides[slideIndex].style.display = "none"; // Hide current slide
    slideIndex = (slideIndex - 1 + slides.length) % slides.length; // Update index
    slides[slideIndex].style.display = "block"; // Show previous slide
    slides[slideIndex].classList.add('fade'); // Add fade class
}

// Initialize the slideshow
showSlides();